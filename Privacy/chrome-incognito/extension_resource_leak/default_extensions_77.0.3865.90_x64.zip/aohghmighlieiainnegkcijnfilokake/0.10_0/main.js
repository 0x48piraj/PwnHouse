document.location.href =
    "https://docs.google.com/document?usp=chrome_app&authuser=0";
